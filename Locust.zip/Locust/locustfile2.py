
from locust import HttpUser, task, between

class HumHubUser(HttpUser):
    wait_time = between(1, 5)  # Wait between 1 to 5 seconds between tasks

    def on_start(self):
        # This method is called when a Locust user starts and is used for login.
        self.login()

    def login(self):
        # Customize these values with your HumHub login credentials and URL
        username = "hossein"
        password = "daradara"
        login_url = "http://localhost/humhub/index.php?r=authentication%2Flogin"

        # Perform the login POST request
        response = self.client.post(
            login_url,
            data={
                "LoginForm[username]": username,
                "LoginForm[password]": password,
                "login-button": "login",
            },
            name="login",
        )

        # Check if login was successful (you can customize this based on HumHub response)
        if response.status_code == 200 and "You are a member" in response.text:
            self.environment.events.request_success.fire(
                request_type="login", name="login", response_time=response.elapsed.total_seconds(), response_length=len(response.content)
            )
        else:
            self.environment.events.request_failure.fire(
                request_type="login", name="login", response_time=response.elapsed.total_seconds(), response_length=len(response.content), exception=None
            )

    @task
    def create_post(self):
        # This task represents a user creating a post in HumHub
        # Replace "http://localhost/humhub/index.php?r=posting%2Fcreate" with the actual URL for creating a post in your HumHub instance
        response = self.client.get("http://localhost/humhub/index.php?r=posting%2Fcreate", name="create_post")

        # Extract the CSRF token from the response to use in the post submission
        csrf_token = self.extract_csrf_token(response.text)

        # Customize the post content
        post_content = "This is a test post created by Locust!"

        # Create the post POST request
        response = self.client.post(
            "http://localhost/humhub/index.php?r=proxy%2Fhttp%2Flocalhost%2Fhumhub%2Findex.php%3Fr%3Dapi%2Fv1%2Fpost&token=" + csrf_token,
            json={
                "message": post_content,
            },
            headers={"Content-Type": "application/json"},
            name="submit_post",
        )

        # Check if the post submission was successful (you can customize this based on HumHub response)
        if response.status_code == 200 and "message" in response.text:
            self.environment.events.request_success.fire(
                request_type="submit_post", name="submit_post", response_time=response.elapsed.total_seconds(), response_length=len(response.content)
            )
        else:
            self.environment.events.request_failure.fire(
                request_type="submit_post", name="submit_post", response_time=response.elapsed.total_seconds(), response_length=len(response.content), exception=None
            )

    def extract_csrf_token(self, html):
        # Helper method to extract the CSRF token from the HumHub HTML response
        import re
        match = re.search(r'content="([^"]+)" name="_csrf"', html)
        if match:
            return match.group(1)