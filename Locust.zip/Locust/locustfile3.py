
from locust import HttpUser, task, between

class HumHubUser(HttpUser):
    wait_time = between(1, 5)  # Wait between 1 to 5 seconds between tasks

    def on_start(self):
        # This method is called when a Locust user starts and is used for login.
        self.login()

    def login(self):
        # Customize these values with your HumHub login credentials and URL
        username = "your_username"
        password = "your_password"
        login_url = "https://your-humhub-instance.com/index.php?r=space%2Fauth&authclient=internal"

        # Perform the login POST request
        response = self.client.post(
            login_url,
            data={
                "LoginForm[username]": username,
                "LoginForm[password]": password,
                "login-button": "login",
            },
            name="login",
        )

        # Check if login was successful (you can customize this based on HumHub response)
        if response.status_code == 200 and "Dashboard - HumHub" in response.text:
            self.environment.events.request_success.fire(
                request_type="login", name="login", response_time=response.elapsed.total_seconds(), response_length=len(response.content)
            )
        else:
            self.environment.events.request_failure.fire(
                request_type="login", name="login", response_time=response.elapsed.total_seconds(), response_length=len(response.content), exception=None
            )

    @task(1)
    def create_vote(self):
        # This task represents a user creating a vote
        # Replace "https://your-humhub-instance.com/index.php?r=space%2Fpoll%2Fcreate" with the actual URL for creating a vote in your HumHub instance
        response = self.client.get("https://your-humhub-instance.com/index.php?r=space%2Fpoll%2Fcreate", name="create_vote")

        # Extract the CSRF token from the response to use in the vote submission
        csrf_token = self.extract_csrf_token(response.text)

        # Create the vote POST request
        vote_title = "Test Vote"
        vote_option1 = "Option 1"
        vote_option2 = "Option 2"
        vote_option3 = "Option 3"

        response = self.client.post(
            "https://your-humhub-instance.com/index.php?r=space%2Fpoll%2Fcreate",
            data={
                "_csrf": csrf_token,
                "Poll[title]": vote_title,
                "Poll[options][]": [vote_option1, vote_option2, vote_option3],
            },
            name="submit_vote",
        )

        # Check if the vote submission was successful (you can customize this based on HumHub response)
        if response.status_code == 200 and "Vote created" in response.text:
            self.environment.events.request_success.fire(
                request_type="submit_vote", name="submit_vote", response_time=response.elapsed.total_seconds(), response_length=len(response.content)
            )
        else:
            self.environment.events.request_failure.fire(
                request_type="submit_vote", name="submit_vote", response_time=response.elapsed.total_seconds(), response_length=len(response.content), exception=None
            )

    def extract_csrf_token(self, html):
        # Helper method to extract the CSRF token from the HumHub HTML response
        import re
        match = re.search(r'content="([^"]+)" name="_csrf"', html)
        if match:
            return match.group(1)
        else:
            raise ValueError("CSRF token not found in HTML response")