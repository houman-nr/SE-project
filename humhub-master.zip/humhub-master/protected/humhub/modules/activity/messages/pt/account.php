<?php
return array (
  'E-Mail Summaries' => 'E-Mails com Resumos',
);
