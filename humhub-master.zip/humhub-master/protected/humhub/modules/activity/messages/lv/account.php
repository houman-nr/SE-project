<?php
return array (
  'E-Mail Summaries' => 'E-pasta kopsavilkumi',
);
