<?php
return array (
  'E-Mail Summaries' => 'Резюмета по електронна поща',
);
