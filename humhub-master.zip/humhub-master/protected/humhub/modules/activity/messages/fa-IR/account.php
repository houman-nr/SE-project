<?php
return array (
  'E-Mail Summaries' => 'چکیده‌های ایمیل',
);
