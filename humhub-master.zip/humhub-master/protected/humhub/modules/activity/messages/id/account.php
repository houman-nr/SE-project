<?php
return array (
  'E-Mail Summaries' => 'Ringkasan Email',
);
