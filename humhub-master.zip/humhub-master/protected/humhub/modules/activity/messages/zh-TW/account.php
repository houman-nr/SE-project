<?php
return array (
  'E-Mail Summaries' => 'E-mail 彙總',
);
