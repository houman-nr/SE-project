<?php
return array (
  'E-Mail Summaries' => 'E-Mail-Zusammenfassungen',
);
