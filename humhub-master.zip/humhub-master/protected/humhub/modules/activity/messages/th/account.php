<?php
return array (
  'E-Mail Summaries' => 'อีเมลสรุป',
);
