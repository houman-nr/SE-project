<?php
return array (
  'E-Mail Summaries' => 'Sommario email',
);
