<?php
return array (
  'E-Mail Summaries' => '邮件概要',
);
