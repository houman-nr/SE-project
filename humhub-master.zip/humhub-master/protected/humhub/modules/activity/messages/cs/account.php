<?php
return array (
  'E-Mail Summaries' => 'Souhrnné emaily',
);
