<?php
return array (
  'E-Mail Summaries' => 'የኢሜል ጥቅል መግለጫ',
);
