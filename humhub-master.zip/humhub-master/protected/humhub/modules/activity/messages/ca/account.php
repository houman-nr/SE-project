<?php
return array (
  'E-Mail Summaries' => 'Resum de correu electrònic',
);
