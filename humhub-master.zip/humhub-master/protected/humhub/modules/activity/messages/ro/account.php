<?php
return array (
  'E-Mail Summaries' => 'Rezumate E-mail',
);
