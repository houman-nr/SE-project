<?php
/* @var $this \humhub\modules\ui\view\components\View */
?>

<h2>My special activity view content</h2>
