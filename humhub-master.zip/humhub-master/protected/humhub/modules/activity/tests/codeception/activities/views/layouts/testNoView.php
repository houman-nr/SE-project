<?php
/* @var $this \humhub\modules\ui\view\components\View */
?>

<div>
    <h1>My special activity view layout without view</h1>
    <?= $content ?>
</div>
