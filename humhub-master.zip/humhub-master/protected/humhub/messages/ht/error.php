<?php

return [
    '<strong>Login</strong> required' => '<strong>Idantifikasyon ou</strong> rekòmande',
    'An internal server error occurred.' => 'Gen yon erè ki pase nan sèvè a.',
    'You are not allowed to perform this action.' => 'Ou pa gen dwa pou\'w fè aksyon sa a.',
    'Guest mode not active, please login first.' => '',
    'Login required for this section.' => '',
    'Maintenance mode activated: You have been automatically logged out and will no longer have access the platform until the maintenance has been completed.' => '',
    'Maintenance mode is active. Only Administrators can access the platform.' => '',
    'The specified URL cannot be called directly.' => '',
    'You are not permitted to access this section.' => '',
    'You must change password.' => '',
    'You need admin permissions to access this section.' => '',
    'Your user account has not been approved yet, please try again later or contact a network administrator.' => '',
    'Your user account is inactive, please login with an active account or contact a network administrator.' => '',
];
