# Local Configuration

Define own application specific configuration values here.